
	function closekortingblock(){
		document.getElementById('popUpKorting').style.display = "none";
		document.cookie = "popUp2=true;";
	}
