
	function closekortingblock(){
		document.getElementById('popUpKorting').style.display = "none";
		document.cookie = "popUpKorting=true;";
	}
